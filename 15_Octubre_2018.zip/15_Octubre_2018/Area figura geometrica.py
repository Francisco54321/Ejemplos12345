import math

radio = input("Ingrese radio: ")

print "Area=", math.pi*radio*radio
